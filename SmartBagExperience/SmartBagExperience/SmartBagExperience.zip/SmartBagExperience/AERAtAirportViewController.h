//
//  AERAtAirportViewController.h
//  SmartBagExperience
//
//  Created by Pedro Garcia Fernandez on 4/7/15.
//  Copyright (c) 2015 aeriaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AERAtAirportViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIButton *atAirport;
@property (nonatomic, weak) IBOutlet UIButton *checkin;
@property (nonatomic, weak) IBOutlet UIButton *myBag;
@property (nonatomic, weak) IBOutlet UIButton *myOffers;

//@property(nonatomic, readonly, strong) UINavigationController *navigationController;

@end
